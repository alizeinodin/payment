<?php

interface Controller
{
    public function validation();
    public function prepare();
}
